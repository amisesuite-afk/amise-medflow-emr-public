/**
 * lib/triage.ts
 *
 * Deterministic triage. Runs BEFORE Claude sees a message for drafting.
 * Red-flag detection here is the safety gate — never bypass it.
 */

import { scanRedFlags, Severity, AppointmentType } from './rules';
import { Classification } from './claude';

export interface TriageResult {
  flagged: boolean;
  severity: Severity | null;
  reasons: string[];
  recommendedAction: 'auto_book' | 'draft_supervised' | 'escalate_urgent' | 'escalate_priority' | 'escalate_review';
  appointmentType: AppointmentType | null;
}

export function triage(
  messageBody: string,
  subject: string,
  classification: Classification
): TriageResult {
  const combined = `${subject}\n${messageBody}`;
  const { flagged, matches } = scanRedFlags(combined);

  if (flagged) {
    // Highest severity wins.
    const order: Severity[] = ['urgent', 'priority', 'review'];
    const highest = order.find(s => matches.some(m => m.severity === s))!;

    return {
      flagged: true,
      severity: highest,
      reasons: matches.map(m => m.reason),
      recommendedAction:
        highest === 'urgent'   ? 'escalate_urgent' :
        highest === 'priority' ? 'escalate_priority' :
                                  'escalate_review',
      appointmentType: null,
    };
  }

  // Map classification category -> appointment type
  const appointmentType: AppointmentType | null =
    classification.category === 'new_consult'  ? 'new_consult' :
    classification.category === 'follow_up'    ? 'follow_up' :
    classification.category === 'post_op'      ? 'post_op' :
    classification.category === 'ercp_workup'  ? 'ercp_workup' :
    classification.category === 'breast'       ? 'breast' :
    null;

  if (!appointmentType) {
    return {
      flagged: false,
      severity: null,
      reasons: ['Out of scope for auto-booking'],
      recommendedAction: 'draft_supervised',
      appointmentType: null,
    };
  }

  // Low-confidence classifications should be supervised.
  if (classification.confidence < 0.7) {
    return {
      flagged: false,
      severity: null,
      reasons: [`Low classifier confidence (${classification.confidence})`],
      recommendedAction: 'draft_supervised',
      appointmentType,
    };
  }

  return {
    flagged: false,
    severity: null,
    reasons: [],
    recommendedAction: 'auto_book',
    appointmentType,
  };
}

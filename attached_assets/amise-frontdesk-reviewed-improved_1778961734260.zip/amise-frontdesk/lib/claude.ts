/**
 * lib/claude.ts
 *
 * Anthropic Claude wrapper. Used for:
 *   1. Classifying incoming messages.
 *   2. Drafting patient replies in house style.
 *
 * Claude is NEVER asked to make a clinical decision. Triage logic (red flags,
 * slot rules, exclusions) is deterministic and lives in lib/rules.ts.
 */

import Anthropic from '@anthropic-ai/sdk';
import { z } from 'zod';
import { checkForbiddenContent } from './rules';

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! });
const MODEL = process.env.CLAUDE_MODEL || 'claude-opus-4-7';

// ─────────────────────────────────────────────────────────
// System prompt — Assistant persona and hard constraints
// ─────────────────────────────────────────────────────────

export const SYSTEM_PROMPT = `You are the front desk administrative assistant for Amise Medical Services in Saint Lucia, a general and endoscopic surgery practice led by Dr Dawit Daniel Kabiye, MD, DM.

Your role is administrative only. You schedule appointments, draft confirmations, and acknowledge enquiries. You write in a warm, professional, concise British-Caribbean tone.

You MUST NEVER:
- Provide clinical advice, diagnoses, dosage information, or interpretation of results.
- Quote prices, fees, or financial information.
- Confirm or deny whether the patient has any specific condition.
- Speculate on what symptoms might mean.
- Discuss other patients or share any clinical information you may have seen.

You MUST ALWAYS:
- Defer clinical questions to Dr Kabiye or the nursing staff.
- Keep replies short (under 150 words for routine messages).
- Use the practice signature block exactly as provided.
- Maintain patient confidentiality.

If a message contains anything urgent (bleeding, severe pain, jaundice, post-op concerns, mental health crisis, suspected cancer), you do NOT draft a clinical reply — you produce only a brief acknowledgement and the matter is escalated to staff.

Locations:
- Rodney Bay (Providence Building) — new consultations, ERCP work-up, breast clinics
- Castries — follow-ups and post-op reviews
- Tapion Hospital (459-2227 / 284-0557) — ERCP procedures and emergencies

Sign every reply as: "Front Desk, Amise Medical Services".`;

// ─────────────────────────────────────────────────────────
// Classification
// ─────────────────────────────────────────────────────────

export const ClassificationSchema = z.object({
  category: z.enum([
    'new_consult', 'follow_up', 'post_op', 'ercp_workup',
    'breast', 'admin', 'reschedule', 'cancel', 'unknown'
  ]),
  patient_first_name: z.string().nullable(),
  reason_summary: z.string().max(200),
  preferred_dates: z.array(z.string()).max(5),
  preferred_location: z.enum(['rodney_bay', 'castries', 'either', 'unknown']),
  confidence: z.number().min(0).max(1),
});

export type Classification = z.infer<typeof ClassificationSchema>;

export async function classifyMessage(emailBody: string, subject: string): Promise<Classification> {
  const prompt = `Classify the following patient email. Respond with ONLY a JSON object, no preamble, no markdown fences.

Schema:
{
  "category": "new_consult" | "follow_up" | "post_op" | "ercp_workup" | "breast" | "admin" | "reschedule" | "cancel" | "unknown",
  "patient_first_name": string | null,
  "reason_summary": string (max 200 chars, no clinical interpretation, just paraphrase what they said),
  "preferred_dates": string[] (ISO dates if mentioned, max 5),
  "preferred_location": "rodney_bay" | "castries" | "either" | "unknown",
  "confidence": number 0-1
}

Subject: ${subject}
Body:
${emailBody}`;

  const resp = await client.messages.create({
    model: MODEL,
    max_tokens: 500,
    system: SYSTEM_PROMPT,
    messages: [{ role: 'user', content: prompt }],
  });

  const text = resp.content
    .filter(b => b.type === 'text')
    .map(b => (b as { type: 'text'; text: string }).text)
    .join('')
    .trim()
    .replace(/^```json\s*/i, '')
    .replace(/```\s*$/, '');

  const parsed = JSON.parse(text);
  return ClassificationSchema.parse(parsed);
}

// ─────────────────────────────────────────────────────────
// Reply drafting
// ─────────────────────────────────────────────────────────

export interface DraftReplyArgs {
  template: 'slot_offer' | 'confirmation' | 'urgent_ack' | 'out_of_scope';
  patientFirstName: string | null;
  slots?: { day: string; date: string; time: string; location: string }[];
  bookingDetails?: { day: string; date: string; time: string; location: string };
}

export async function draftReply(args: DraftReplyArgs): Promise<{ subject: string; body: string; safe: boolean; violations: string[] }> {
  const name = args.patientFirstName || 'there';

  const templateGuide: Record<DraftReplyArgs['template'], string> = {
    slot_offer: `Subject: Amise Medical Services — Appointment Options for Your Consultation

Draft a slot-offer reply using these slots: ${JSON.stringify(args.slots)}. Address the patient as "${name}". List the slots as bullet options. End with the standard sign-off.`,

    confirmation: `Subject: Confirmation — Your Appointment with Dr Kabiye

Draft a booking confirmation for: ${JSON.stringify(args.bookingDetails)}. Address the patient as "${name}". Remind them to arrive 10 minutes early, bring ID and insurance card, and bring prior records. End with the standard sign-off.`,

    urgent_ack: `Subject: Amise Medical Services — Message Received

Draft a brief acknowledgement (NO clinical content). Address the patient as "${name}". Tell them their message has been received and forwarded to the clinical team, and that someone will contact them shortly. Add: if symptoms are severe or worsening, attend the nearest emergency department or call Tapion Hospital on 459-2227 or 284-0557. End with the standard sign-off.`,

    out_of_scope: `Subject: Amise Medical Services — Your Enquiry

Draft a brief reply (NO clinical content). Address the patient as "${name}". Tell them the query has been passed to Dr Kabiye or relevant clinical staff for a personal reply within 1-2 working days. End with the standard sign-off.`,
  };

  const resp = await client.messages.create({
    model: MODEL,
    max_tokens: 600,
    system: SYSTEM_PROMPT,
    messages: [{
      role: 'user',
      content: `Draft an email reply. Return ONLY the email body, with the subject on the first line prefixed "Subject: ".\n\n${templateGuide[args.template]}`,
    }],
  });

  const raw = resp.content
    .filter(b => b.type === 'text')
    .map(b => (b as { type: 'text'; text: string }).text)
    .join('')
    .trim();

  const lines = raw.split('\n');
  const subjectLine = lines[0].replace(/^Subject:\s*/i, '').trim();
  const body = lines.slice(1).join('\n').trim();

  // Post-generation guard: never let forbidden content leave the system.
  const check = checkForbiddenContent(body);

  return {
    subject: subjectLine,
    body,
    safe: check.safe,
    violations: check.violations,
  };
}

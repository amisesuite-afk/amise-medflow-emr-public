# Amise Front Desk AI

Automated front-desk assistant for **Amise Medical Services** — triages incoming patient email, finds appointment slots in Google Calendar, drafts confirmations, and dispatches SMS reminders. Built on Next.js + Vercel + Supabase + Anthropic Claude + Google APIs + Twilio.

> Operating rules document: `docs/Amise_FrontDeskAI_Operating_Rules_v1.docx` (separate file). The code in `lib/rules.ts` is the machine-readable mirror of that document.

---


## Adaptive triage dashboard

The root page (`/`) now provides a compact supervised triage dashboard with:

- Patient basics, duration, pain score, post-op status, pregnancy possibility.
- Vitals: BP, HR, temperature, respiratory rate, SpO₂, and random blood sugar.
- PMH/comorbidities, surgical history, medications, allergies, and toxic habits.
- Adaptive risk score, acuity band, recommended administrative action, and safe front-desk script.
- Suggested EMR blocks based on presentation type, such as ERCP/biliary, breast, post-op, endoscopy, or hernia.

The browser dashboard uses `lib/adaptive-triage.ts`, the same deterministic rule engine exposed through `/api/triage/preview`. It does not provide diagnosis or treatment advice.

## Architecture

```
Patient email  ──►  Gmail (appointments@…)
                        │
                        ▼
              ┌─────────────────────┐
              │  /api/intake        │  Polled every 2 min by Vercel cron
              │  (Gmail watch /     │  or push via Pub/Sub webhook
              │   poll handler)     │
              └─────────┬───────────┘
                        │
                        ▼
              ┌─────────────────────┐
              │  Triage engine      │  Claude classifies + red-flag scan
              │  (lib/triage.ts)    │
              └─────────┬───────────┘
                        │
                ┌───────┴───────┐
                ▼               ▼
        URGENT / FLAG       ROUTINE
                │               │
                ▼               ▼
        Notify staff       Slot finder
        (no auto-reply)    (Google Calendar)
                                │
                                ▼
                        Draft reply (Gmail)
                                │
                                ▼
                        Patient picks slot
                                │
                                ▼
                        Create Calendar event
                                │
                                ▼
                        Supabase: bookings row
                                │
                                ▼
                Reminder cron (T-48h / T-24h / T-2h)
                                │
                                ▼
                        Twilio SMS / Gmail
```

State lives in Supabase. Scheduled work runs on Vercel cron. Claude is called server-side only — no API keys in the browser.

---

## Repository layout

```
amise-frontdesk/
├── app/api/
│   ├── intake/route.ts              POST: receive new email, classify, draft reply
│   ├── cron/reminders/route.ts      Vercel cron: dispatch due reminders
│   └── cron/daily-summary/route.ts  Vercel cron: 18:00 summary email to Dr Kabiye
├── lib/
│   ├── claude.ts        Anthropic SDK wrapper + prompt builders
│   ├── triage.ts        Red-flag detection, classification, slot-type mapping
│   ├── calendar.ts      Google Calendar: free/busy, create, update events
│   ├── gmail.ts         Gmail: list, read, draft, send
│   ├── sms.ts           Twilio SMS dispatcher
│   ├── supabase.ts      DB client + typed queries
│   └── rules.ts         Operating rules (slots, exclusions, red-flags) — single source of truth
├── supabase/schema.sql  Database schema
├── .github/workflows/   CI: typecheck + lint
├── .env.example
├── vercel.json          Cron schedule
├── package.json
└── tsconfig.json
```

---

## Quick start

### 1. Clone and install

```bash
git clone https://github.com/<your-org>/amise-frontdesk.git
cd amise-frontdesk
npm install
```

### 2. Supabase

Create a project at supabase.com, then run the schema:

```bash
psql "$SUPABASE_DB_URL" -f supabase/schema.sql
```

### 3. Google APIs

Enable Gmail API and Calendar API in Google Cloud Console. Create a service account, share the practice calendar and the appointments inbox with the service account's email, download the JSON key, and paste it into `GOOGLE_SERVICE_ACCOUNT_JSON` in `.env`.

### 4. Anthropic and Twilio

Get an Anthropic API key from console.anthropic.com. Get a Twilio account and SMS-capable number (use a local Saint Lucia gateway if Twilio coverage is limited; the SMS module is provider-agnostic and easy to swap).

### 5. Environment variables

Copy `.env.example` to `.env.local` and fill in every value.

### 6. Local development

```bash
npm run dev
```

The intake endpoint is at `http://localhost:3000/api/intake`. To simulate a new email, POST a Gmail message ID to it.

### 7. Deploy to Vercel

```bash
vercel link
vercel env pull
vercel --prod
```

Cron schedules in `vercel.json` will activate automatically.

---

## Operating modes

Set `MODE` in env to one of:

| Mode | Behaviour |
|------|-----------|
| `dry_run` | Triage and draft everything. **Send nothing.** Log to Supabase. Use this in week 1. |
| `supervised` | Drafts saved to Gmail Drafts folder for staff review. No auto-send. Default during weeks 2–4. |
| `auto` | Auto-send routine confirmations. Red flags still escalate to humans. Full Phase 3 mode. |

Mode is enforced in `lib/gmail.ts:sendOrDraft()`. Never deploy `auto` mode without running `supervised` for at least two weeks.

---

## Safety guarantees (hardcoded, not configurable)

1. **Red-flag detection runs before any reply is drafted.** A positive match short-circuits the auto-reply path.
2. **The Assistant never quotes prices, dosages, or results.** Enforced in the Claude system prompt (`lib/claude.ts:SYSTEM_PROMPT`) and validated by a post-generation regex check.
3. **No clinical content in SMS.** SMS bodies are template-only and never include free-text from Claude.
4. **Bookings are append-only.** Existing Calendar events are never overwritten by the Assistant.
5. **All actions are logged.** Every triage decision, draft, send, and reminder writes to `audit_log` in Supabase.

---

## CI / CD

GitHub Actions runs typecheck and lint on every PR. Merges to `main` trigger a Vercel preview deployment; tagged releases (`v*`) trigger production.

---

## Roadmap

- [x] v0.1 — Triage + slot finder + drafts (dry-run)
- [ ] v0.2 — Reminder cascade (T-48h / T-24h / T-2h)
- [ ] v0.3 — OpenEMR sync via Zapier or direct FHIR API
- [ ] v0.4 — WhatsApp Business intake channel
- [ ] v0.5 — Waitlist auto-fill on cancellation
- [ ] v1.0 — Patient self-service web portal (separate repo, shared Supabase)

---

## Licence

Proprietary. © Verdance Holdings Ltd / Amise Medical Services. Not for redistribution.

-- ─────────────────────────────────────────────────────────────
-- AMISE FRONT DESK AI — Supabase schema
-- Run with: psql "$SUPABASE_DB_URL" -f supabase/schema.sql
-- ─────────────────────────────────────────────────────────────

create extension if not exists "uuid-ossp";

-- Patients (minimal demographics; OpenEMR remains source of truth)
create table if not exists patients (
  id uuid primary key default uuid_generate_v4(),
  email text unique,
  phone text,
  first_name text,
  last_name text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Inbound messages from patients
create table if not exists messages (
  id uuid primary key default uuid_generate_v4(),
  gmail_message_id text unique not null,
  thread_id text,
  patient_id uuid references patients(id),
  from_email text not null,
  subject text,
  body text,
  received_at timestamptz not null,
  classification text,           -- new_consult | follow_up | ercp | urgent | admin | unknown
  red_flag boolean default false,
  red_flag_reason text,
  reply_drafted boolean default false,
  reply_sent boolean default false,
  reply_gmail_id text,
  created_at timestamptz default now()
);

create index if not exists messages_patient_idx on messages(patient_id);
create index if not exists messages_received_idx on messages(received_at desc);

-- Bookings (mirror of Calendar events; Calendar remains source of truth)
create table if not exists bookings (
  id uuid primary key default uuid_generate_v4(),
  calendar_event_id text unique not null,
  calendar_id text not null,
  patient_id uuid references patients(id),
  appointment_type text not null,  -- new_consult | follow_up | post_op | ercp_workup | ercp | breast | telephone
  location text not null,          -- rodney_bay | castries | tapion | remote
  start_at timestamptz not null,
  end_at timestamptz not null,
  status text default 'confirmed', -- confirmed | rescheduled | cancelled | no_show | completed
  reason text,
  source_message_id uuid references messages(id),
  emr_synced boolean default false,
  emr_encounter_id text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index if not exists bookings_start_idx on bookings(start_at);
create index if not exists bookings_patient_idx on bookings(patient_id);
create index if not exists bookings_status_idx on bookings(status);

-- Reminders queue
create table if not exists reminders (
  id uuid primary key default uuid_generate_v4(),
  booking_id uuid not null references bookings(id) on delete cascade,
  kind text not null,              -- sms_48h | email_24h | sms_2h | post_visit_24h
  scheduled_for timestamptz not null,
  sent_at timestamptz,
  status text default 'pending',   -- pending | sent | failed | cancelled
  error text,
  created_at timestamptz default now()
);

create index if not exists reminders_due_idx on reminders(scheduled_for) where status = 'pending';

-- Append-only audit log (every Assistant action)
create table if not exists audit_log (
  id uuid primary key default uuid_generate_v4(),
  ts timestamptz default now(),
  actor text default 'assistant',  -- assistant | staff | system
  action text not null,            -- classify | draft | send | book | remind | escalate | error
  entity_type text,                -- message | booking | reminder
  entity_id uuid,
  payload jsonb,
  mode text                        -- dry_run | supervised | auto
);

create index if not exists audit_ts_idx on audit_log(ts desc);
create index if not exists audit_entity_idx on audit_log(entity_type, entity_id);

-- Flagged items requiring human review
create table if not exists escalations (
  id uuid primary key default uuid_generate_v4(),
  message_id uuid references messages(id),
  reason text not null,
  severity text not null,          -- urgent | priority | review
  notified_at timestamptz,
  resolved_at timestamptz,
  resolved_by text,
  notes text,
  created_at timestamptz default now()
);

create index if not exists escalations_unresolved_idx on escalations(created_at) where resolved_at is null;

-- Waitlist
create table if not exists waitlist (
  id uuid primary key default uuid_generate_v4(),
  patient_id uuid references patients(id),
  appointment_type text not null,
  preferred_location text,
  preferred_window text,
  notes text,
  created_at timestamptz default now(),
  filled_booking_id uuid references bookings(id)
);

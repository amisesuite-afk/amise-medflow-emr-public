import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { adaptiveTriage } from '@/lib/adaptive-triage';

const NullableNumber = z.union([z.number(), z.null()]).optional();

const TriagePreviewSchema = z.object({
  age: NullableNumber,
  sex: z.enum(['female', 'male', 'other', 'unknown']).optional(),
  symptoms: z.array(z.string()).default([]),
  freeText: z.string().optional(),
  comorbidities: z.array(z.string()).optional(),
  surgicalHistory: z.array(z.string()).optional(),
  medications: z.array(z.string()).optional(),
  allergies: z.array(z.string()).optional(),
  toxicHabits: z.array(z.string()).optional(),
  vitalSigns: z.object({
    systolicBp: NullableNumber,
    diastolicBp: NullableNumber,
    heartRate: NullableNumber,
    temperatureC: NullableNumber,
    respiratoryRate: NullableNumber,
    spo2: NullableNumber,
    glucoseMmol: NullableNumber,
  }).optional(),
  durationDays: NullableNumber,
  painScore: NullableNumber,
  isPostOp: z.boolean().optional(),
  postOpDays: NullableNumber,
  pregnancyPossible: z.boolean().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const parsed = TriagePreviewSchema.parse(await req.json());
    return NextResponse.json(adaptiveTriage(parsed));
  } catch (error) {
    return NextResponse.json({ error: 'Invalid triage request', detail: String(error) }, { status: 400 });
  }
}

/**
 * app/api/intake/route.ts
 *
 * Triggered every 2 minutes by Vercel cron (?source=poll) and optionally by
 * Gmail Pub/Sub push notifications.
 *
 * Flow:
 *   1. List unread messages.
 *   2. For each: parse → classify → triage.
 *   3. If urgent → log escalation, draft brief ack, notify staff.
 *   4. If routine → find slots, draft slot offer (mode-gated send).
 *   5. Mark message as read; write audit log.
 */

import { NextRequest, NextResponse } from 'next/server';
import { listUnreadMessages, getMessage, markRead, sendOrDraft } from '@/lib/gmail';
import { classifyMessage, draftReply } from '@/lib/claude';
import { triage } from '@/lib/triage';
import { findSlots, formatSlotForDisplay } from '@/lib/calendar';
import { sb, audit, upsertPatient } from '@/lib/supabase';

export const maxDuration = 60;

export async function GET(req: NextRequest) {
  return handle(req);
}

export async function POST(req: NextRequest) {
  return handle(req);
}

async function handle(req: NextRequest) {
  // Auth check for cron
  const auth = req.headers.get('authorization');
  if (process.env.CRON_SECRET && auth !== `Bearer ${process.env.CRON_SECRET}`) {
    // Allow Vercel cron via its own header; otherwise require Bearer.
    const vercelCron = req.headers.get('x-vercel-cron');
    if (!vercelCron) return new NextResponse('Unauthorized', { status: 401 });
  }

  const ids = await listUnreadMessages(20);
  const results: { id: string; outcome: string }[] = [];

  for (const id of ids) {
    try {
      const outcome = await processOne(id);
      results.push({ id, outcome });
    } catch (err) {
      console.error(`[intake] ${id} failed:`, err);
      await audit({ action: 'error', entityType: 'message', entityId: id, payload: { error: String(err) } });
      results.push({ id, outcome: 'error' });
    }
  }

  return NextResponse.json({ processed: results.length, results });
}

async function processOne(messageId: string): Promise<string> {
  const msg = await getMessage(messageId);

  // De-duplicate: skip if we've already processed this gmail_message_id.
  const { data: existing } = await sb()
    .from('messages')
    .select('id')
    .eq('gmail_message_id', msg.id)
    .maybeSingle();

  if (existing) {
    await markRead(messageId);
    return 'already_processed';
  }

  // Upsert patient.
  const patientId = await upsertPatient({
    email: msg.from,
    firstName: msg.fromName?.split(' ')[0] || null,
    lastName: msg.fromName?.split(' ').slice(1).join(' ') || null,
  });

  // Classify with Claude.
  const classification = await classifyMessage(msg.body, msg.subject);
  await audit({
    action: 'classify',
    entityType: 'message',
    entityId: msg.id,
    payload: { classification },
  });

  // Triage (deterministic, rules-based).
  const triageResult = triage(msg.body, msg.subject, classification);
  await audit({
    action: 'triage',
    entityType: 'message',
    entityId: msg.id,
    payload: { triageResult },
  });

  // Record the message.
  const { data: msgRow } = await sb().from('messages').insert({
    gmail_message_id: msg.id,
    thread_id: msg.threadId,
    patient_id: patientId,
    from_email: msg.from,
    subject: msg.subject,
    body: msg.body,
    received_at: msg.receivedAt.toISOString(),
    classification: classification.category,
    red_flag: triageResult.flagged,
    red_flag_reason: triageResult.reasons.join('; ') || null,
  }).select('id').single();

  const msgRowId = msgRow!.id;

  // ─── URGENT escalation path ───
  if (triageResult.recommendedAction.startsWith('escalate')) {
    await sb().from('escalations').insert({
      message_id: msgRowId,
      reason: triageResult.reasons.join('; '),
      severity: triageResult.severity,
    });

    // Brief acknowledgement only.
    const draft = await draftReply({
      template: 'urgent_ack',
      patientFirstName: classification.patient_first_name,
    });

    if (!draft.safe) {
      await audit({ action: 'skip', entityType: 'message', entityId: msg.id, payload: { reason: 'forbidden_content', violations: draft.violations } });
    } else {
      const result = await sendOrDraft({
        to: msg.from,
        subject: draft.subject,
        body: draft.body,
        threadId: msg.threadId,
      });
      await audit({ action: result.action === 'sent' ? 'send' : 'draft', entityType: 'message', entityId: msg.id, payload: { kind: 'urgent_ack', result } });
    }

    // TODO: notify staff by SMS — implement in next iteration.
    await markRead(messageId);
    return `escalated_${triageResult.severity}`;
  }

  // ─── Out-of-scope: draft supervised reply ───
  if (triageResult.recommendedAction === 'draft_supervised' || !triageResult.appointmentType) {
    const draft = await draftReply({
      template: 'out_of_scope',
      patientFirstName: classification.patient_first_name,
    });

    if (draft.safe) {
      const result = await sendOrDraft({
        to: msg.from,
        subject: draft.subject,
        body: draft.body,
        threadId: msg.threadId,
      }, 'supervised'); // force supervised — never auto-send out-of-scope
      await audit({ action: 'draft', entityType: 'message', entityId: msg.id, payload: { kind: 'out_of_scope', result } });
    }

    await markRead(messageId);
    return 'supervised_draft';
  }

  // ─── Routine: find slots and offer ───
  const slots = await findSlots(triageResult.appointmentType, { max: 3, lookaheadDays: 21 });

  if (slots.length === 0) {
    // No slots — defer to staff.
    const draft = await draftReply({
      template: 'out_of_scope',
      patientFirstName: classification.patient_first_name,
    });
    if (draft.safe) {
      await sendOrDraft({
        to: msg.from,
        subject: draft.subject,
        body: draft.body,
        threadId: msg.threadId,
      }, 'supervised');
    }
    await markRead(messageId);
    return 'no_slots';
  }

  const formattedSlots = slots.map(formatSlotForDisplay);
  const draft = await draftReply({
    template: 'slot_offer',
    patientFirstName: classification.patient_first_name,
    slots: formattedSlots,
  });

  if (!draft.safe) {
    await audit({ action: 'skip', entityType: 'message', entityId: msg.id, payload: { reason: 'forbidden_content', violations: draft.violations } });
  } else {
    const result = await sendOrDraft({
      to: msg.from,
      subject: draft.subject,
      body: draft.body,
      threadId: msg.threadId,
    });
    await audit({ action: result.action === 'sent' ? 'send' : 'draft', entityType: 'message', entityId: msg.id, payload: { kind: 'slot_offer', result, slots: formattedSlots } });

    await sb().from('messages').update({
      reply_drafted: true,
      reply_sent: result.action === 'sent',
      reply_gmail_id: result.gmailId || null,
    }).eq('id', msgRowId);
  }

  await markRead(messageId);
  return 'slot_offer';
}

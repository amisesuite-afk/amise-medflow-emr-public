/**
 * app/api/cron/reminders/route.ts
 *
 * Runs every 15 minutes. Dispatches any reminders whose scheduled_for is now or past.
 */

import { NextRequest, NextResponse } from 'next/server';
import { sb, audit } from '@/lib/supabase';
import { sendSms, smsBody48h, smsBody2h } from '@/lib/sms';
import { sendOrDraft } from '@/lib/gmail';

export const maxDuration = 60;

interface ReminderPatient {
  email?: string | null;
  phone?: string | null;
  first_name?: string | null;
}

interface ReminderBooking {
  start_at: string;
  location: string;
  patients?: ReminderPatient | null;
}

interface ReminderRow {
  id: string;
  kind: 'sms_48h' | 'sms_2h' | 'email_24h' | 'post_visit_24h' | string;
  bookings?: ReminderBooking | null;
}


export async function GET(req: NextRequest) {
  return handle(req);
}

async function handle(req: NextRequest) {
  const auth = req.headers.get('authorization');
  if (process.env.CRON_SECRET && auth !== `Bearer ${process.env.CRON_SECRET}`) {
    if (!req.headers.get('x-vercel-cron')) {
      return new NextResponse('Unauthorized', { status: 401 });
    }
  }

  const now = new Date().toISOString();

  const { data: due } = await sb()
    .from('reminders')
    .select('*, bookings(*, patients(*))')
    .eq('status', 'pending')
    .lte('scheduled_for', now)
    .limit(50);

  if (!due || due.length === 0) {
    return NextResponse.json({ dispatched: 0 });
  }

  let dispatched = 0;
  for (const r of due) {
    try {
      await dispatchOne(r);
      dispatched++;
    } catch (err) {
      await sb().from('reminders').update({
        status: 'failed',
        error: String(err),
      }).eq('id', r.id);
      await audit({ action: 'error', entityType: 'reminder', entityId: r.id, payload: { error: String(err) } });
    }
  }

  return NextResponse.json({ dispatched, total: due.length });
}

async function dispatchOne(r: ReminderRow): Promise<void> {
  const booking = r.bookings;
  const patient = booking?.patients;
  if (!booking || !patient) throw new Error('Missing booking or patient');

  const start = new Date(booking.start_at);
  const day = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][start.getDay()];
  const date = `${start.getDate()}/${start.getMonth() + 1}`;
  const time = `${pad(start.getHours())}:${pad(start.getMinutes())}`;
  const location = ({ rodney_bay: 'Rodney Bay', castries: 'Castries', tapion: 'Tapion', remote: 'Phone' } as Record<string, string>)[booking.location] || booking.location;

  if (r.kind === 'sms_48h') {
    if (!patient.phone) throw new Error('No phone');
    await sendSms({ to: patient.phone, body: smsBody48h({ day, date, time, location }) });
  } else if (r.kind === 'sms_2h') {
    if (!patient.phone) throw new Error('No phone');
    await sendSms({ to: patient.phone, body: smsBody2h({ location }) });
  } else if (r.kind === 'email_24h') {
    if (!patient.email) throw new Error('No email');
    await sendOrDraft({
      to: patient.email,
      subject: 'Reminder — Your Appointment Tomorrow at Amise Medical',
      body:
`Dear ${patient.first_name || 'there'},

This is a reminder that your appointment with Dr Kabiye is tomorrow, ${day} ${date} at ${time}, at our ${location} office.

Please arrive 10 minutes early. Bring a valid ID, your insurance card if applicable, and any prior medical records relevant to your visit.

If you need to reschedule, please reply to this email or call us as soon as possible.

Warm regards,
Front Desk, Amise Medical Services`,
    });
  } else if (r.kind === 'post_visit_24h') {
    if (!patient.email) throw new Error('No email');
    await sendOrDraft({
      to: patient.email,
      subject: 'Thank You — Amise Medical Services',
      body:
`Dear ${patient.first_name || 'there'},

Thank you for visiting Amise Medical Services. We hope your appointment went well.

If you have any administrative follow-up needs (test scheduling, paperwork, copies of letters), please reply to this email and we will assist you.

Warm regards,
Front Desk, Amise Medical Services`,
    });
  }

  await sb().from('reminders').update({
    status: 'sent',
    sent_at: new Date().toISOString(),
  }).eq('id', r.id);

  await audit({ action: 'remind', entityType: 'reminder', entityId: r.id, payload: { kind: r.kind } });
}

function pad(n: number): string {
  return n.toString().padStart(2, '0');
}

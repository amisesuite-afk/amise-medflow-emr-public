/**
 * app/api/cron/daily-summary/route.ts
 *
 * Runs at 18:00 local (22:00 UTC) Mon-Fri. Emails Dr Kabiye a one-page summary.
 */

import { NextRequest, NextResponse } from 'next/server';
import { sb, audit } from '@/lib/supabase';
import { sendOrDraft } from '@/lib/gmail';

export const maxDuration = 30;

interface PatientSummary {
  first_name?: string | null;
  last_name?: string | null;
}

interface CreatedBookingSummary {
  appointment_type: string;
  location: string;
  start_at: string;
  patients?: PatientSummary | PatientSummary[] | null;
}

interface ChangedBookingSummary {
  status: string;
  appointment_type: string;
  start_at: string;
}

interface FlaggedSummary {
  severity: string;
  reason: string;
  created_at: string;
}

interface UpcomingSummary {
  start_at: string;
}

function firstPatient(value: PatientSummary | PatientSummary[] | null | undefined): PatientSummary | null {
  if (Array.isArray(value)) return value[0] || null;
  return value || null;
}


export async function GET(req: NextRequest) {
  const auth = req.headers.get('authorization');
  if (process.env.CRON_SECRET && auth !== `Bearer ${process.env.CRON_SECRET}`) {
    if (!req.headers.get('x-vercel-cron')) {
      return new NextResponse('Unauthorized', { status: 401 });
    }
  }

  const now = new Date();
  const since = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  const next3 = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000);

  // Bookings created in last 24h
  const { data: created } = await sb()
    .from('bookings')
    .select('id, appointment_type, location, start_at, patients(first_name, last_name)')
    .gte('created_at', since.toISOString())
    .order('start_at');

  // Reschedules / cancellations in last 24h
  const { data: changed } = await sb()
    .from('bookings')
    .select('id, status, appointment_type, location, start_at')
    .in('status', ['rescheduled', 'cancelled', 'no_show'])
    .gte('updated_at', since.toISOString());

  // Flagged messages unresolved
  const { data: flagged } = await sb()
    .from('escalations')
    .select('id, severity, reason, created_at')
    .is('resolved_at', null)
    .order('created_at', { ascending: false });

  // Upcoming load
  const { data: upcoming } = await sb()
    .from('bookings')
    .select('appointment_type, location, start_at')
    .gte('start_at', now.toISOString())
    .lte('start_at', next3.toISOString())
    .order('start_at');

  const body = composeSummary({ created, changed, flagged, upcoming });

  await sendOrDraft({
    to: process.env.DOCTOR_NOTIFY_EMAIL!,
    subject: `Amise Daily Summary — ${now.toDateString()}`,
    body,
  }, 'auto'); // summary always sends

  await audit({ action: 'send', entityType: 'summary', payload: { date: now.toISOString() } });

  return NextResponse.json({ ok: true });
}

function composeSummary(args: {
  created: CreatedBookingSummary[] | null;
  changed: ChangedBookingSummary[] | null;
  flagged: FlaggedSummary[] | null;
  upcoming: UpcomingSummary[] | null;
}): string {
  const lines: string[] = [];
  lines.push(`AMISE FRONT DESK — DAILY SUMMARY`);
  lines.push(`Generated: ${new Date().toLocaleString('en-GB', { timeZone: 'America/St_Lucia' })}`);
  lines.push('');

  lines.push(`Bookings created (last 24h): ${args.created?.length || 0}`);
  for (const b of args.created || []) {
    const patient = firstPatient(b.patients);
    const name = patient ? `${patient.first_name || ''} ${patient.last_name || ''}`.trim() || 'Unknown' : 'Unknown';
    lines.push(`  • ${name} — ${b.appointment_type} — ${new Date(b.start_at).toLocaleString('en-GB', { timeZone: 'America/St_Lucia' })} — ${b.location}`);
  }
  lines.push('');

  lines.push(`Reschedules / cancellations / no-shows (last 24h): ${args.changed?.length || 0}`);
  for (const c of args.changed || []) {
    lines.push(`  • ${c.status.toUpperCase()} — ${c.appointment_type} — ${new Date(c.start_at).toLocaleString('en-GB', { timeZone: 'America/St_Lucia' })}`);
  }
  lines.push('');

  lines.push(`Flagged messages awaiting review: ${args.flagged?.length || 0}`);
  for (const f of args.flagged || []) {
    lines.push(`  • [${f.severity.toUpperCase()}] ${f.reason} — ${new Date(f.created_at).toLocaleString('en-GB', { timeZone: 'America/St_Lucia' })}`);
  }
  lines.push('');

  lines.push(`Upcoming load (next 3 days): ${args.upcoming?.length || 0}`);
  const byDay = new Map<string, number>();
  for (const u of args.upcoming || []) {
    const d = new Date(u.start_at).toDateString();
    byDay.set(d, (byDay.get(d) || 0) + 1);
  }
  for (const [d, n] of byDay) {
    lines.push(`  • ${d}: ${n} appointment(s)`);
  }
  lines.push('');
  lines.push('— Amise Front Desk AI');

  return lines.join('\n');
}

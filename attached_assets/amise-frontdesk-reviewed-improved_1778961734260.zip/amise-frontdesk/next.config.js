/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  experimental: {
    serverActions: { allowedOrigins: ['localhost:3000'] },
    // Keep large server-only SDKs out of the server component bundling pass.
    serverComponentsExternalPackages: ['googleapis', '@anthropic-ai/sdk', 'twilio', '@supabase/supabase-js'],
  },
};

module.exports = nextConfig;

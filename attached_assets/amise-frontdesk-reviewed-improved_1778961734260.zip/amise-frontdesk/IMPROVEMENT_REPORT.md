# Amise Front Desk — Review & Improvement Report

## Completed improvements

### React / UI
- Rebuilt the main dashboard into a compact tabbed workflow: Intake, Triage, Script, Ops.
- Added missing clinical-administrative intake sections: PMH/comorbidities, surgical history, medications, allergies, toxic habits, vitals, post-op days, pregnancy possibility.
- Added mobile-friendly spacing, horizontal tabs, tighter cards, and clearer acuity display.
- Added a safe front-desk script generator so staff have a copy-ready response without clinical advice.
- Added adaptive EMR block suggestions so the form can expand based on presentation type.

### Adaptive triage engine
- Expanded risk scoring beyond symptoms to include age, sex, comorbidities, medications, anticoagulants, diabetic medication, vital signs, post-op status, pain score, pregnancy possibility, and free text.
- Added missing-critical-field detection for age, sex, complaint, duration, medications, allergies, and pain score.
- Added additional red-flag recognition for fever/rigors/confusion/collapse and possible obstruction/complicated hernia.
- Added pathway-specific prompts for ERCP/biliary, breast, post-op, endoscopy, and hernia cases.
- Added safe front-desk scripting by acuity level.

### API hardening
- Added Zod validation to `/api/triage/preview` to prevent malformed triage payloads.
- Kept triage deterministic and rule-based; AI/Claude remains for classification and drafting only.

### Scheduling rules
- Adjusted new-consult duration to 45 minutes, matching the preferred appointment model.
- Updated new consult clinic windows to Monday/Thursday/Friday 10:00–17:00.
- Improved calendar exclusion handling so protected blocks are checked per slot rather than by broad day-only logic.

### Build quality
- `npm run typecheck` passes.
- `npm run lint` passes.
- Added externalization hint for server-only SDK packages in Next config.

## Important notes before deployment

1. Keep `MODE=dry_run` first, then `MODE=supervised`. Do not use `MODE=auto` until staff have reviewed real cases for at least two weeks.
2. The triage engine is an administrative safety tool, not a diagnosis or treatment engine.
3. Current dependency audit shows unresolved Next/PostCSS advisories that npm proposes fixing through a major Next upgrade. I did not force a major upgrade because it may require framework migration testing.
4. Production build in this container repeatedly timed out during the Next optimization stage, despite typecheck and lint passing. Test `npm run build` locally or on Vercel with full build resources.


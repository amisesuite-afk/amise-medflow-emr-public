# Patch Notes — React Fix + Adaptive Triage

## What was fixed

- Added missing Next.js React app entry files:
  - `app/layout.tsx`
  - `app/page.tsx`
  - `app/globals.css`
- Added a working mobile-friendly React dashboard for front desk triage.
- Added deterministic adaptive triage logic in `lib/adaptive-triage.ts`.
- Added API preview endpoint: `POST /api/triage/preview`.
- Fixed TypeScript/lint issues in existing calendar and cron files that blocked production builds.
- Added `package-lock.json` for reproducible installs.

## Adaptive triage inputs now considered

- Age
- Sex
- Main symptoms / free text
- Duration
- Pain score
- Post-operative status
- Pregnancy possibility
- Comorbidities
- Medications, especially anticoagulants/antiplatelets
- Allergies
- Existing red-flag rules

## Triage outputs

- Acuity: `routine`, `review`, `priority`, or `urgent`
- Score
- Recommended action
- Appointment type suggestion
- Red-flag reasons
- Next questions for front desk staff
- Safety message

## Local setup

```bash
npm install
npm run dev
```

Open:

```text
http://localhost:3000
```

## Validation performed

```bash
npm run typecheck
```

TypeScript validation passed.

`next build` successfully compiled and generated static pages, but the container timed out during final build trace collection. On a normal local machine or Vercel, rerun:

```bash
NEXT_TELEMETRY_DISABLED=1 npm run build
```
